<?php
// Simple about page
$page_title = "About Us";
include 'includes/header.php';
?>

<div class="main-content" style="text-align: center; padding: 50px;">
    <h1>About Us</h1>
    <p>Welcome to <?php echo SITE_NAME; ?> – your all‑in‑one platform for learning, teaching, and career opportunities.</p>
    <p>We are dedicated to providing high‑quality online courses, a job portal, and an e‑commerce store for educational materials.</p>
    <p><a href="index.php" class="btn btn-primary">Back to Home</a></p>
</div>

<?php include 'includes/footer.php'; ?>