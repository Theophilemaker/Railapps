<?php
require_once 'functions.php';

// Check if PHPMailer exists, use appropriate path
$phpmailer_paths = [
    __DIR__ . '/../vendor/autoload.php', // Composer install
    __DIR__ . '/../PHPMailer/src/Exception.php', // Manual download
];

$phpmailer_found = false;
foreach ($phpmailer_paths as $path) {
    if (file_exists($path)) {
        if (basename($path) == 'autoload.php') {
            require_once $path;
        } else {
            require_once __DIR__ . '/../PHPMailer/src/Exception.php';
            require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
            require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
        }
        $phpmailer_found = true;
        break;
    }
}

// If PHPMailer not found, define a fallback
if (!$phpmailer_found) {
    // We'll use log only mode
    define('PHPMailer\PHPMailer\PHPMailer', 1);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class NotificationSystem {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Send Email using SMTP (works on WAMP)
    public function sendEmail($to, $subject, $message) {
        // Check if PHPMailer class exists
        if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            return $this->sendEmailLogOnly($to, $subject, $message);
        }
        
        $mail = new PHPMailer(true);
        
        try {
            // Server settings for Gmail (works on WAMP)
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'your-email@gmail.com'; // CHANGE THIS
            $mail->Password   = 'your-app-password';    // CHANGE THIS
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            
            // Recipients
            $mail->setFrom('noreply@edusmart.com', SITE_NAME);
            $mail->addAddress($to);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $this->buildEmailTemplate($subject, $message);
            
            $mail->send();
            $this->logNotification(null, 'email', $subject, $message, 'sent');
            return true;
            
        } catch (Exception $e) {
            error_log("Mailer Error: " . $mail->ErrorInfo);
            // Fallback to logging
            return $this->sendEmailLogOnly($to, $subject, $message);
        }
    }
    
    // Log email only (for testing - always works)
    public function sendEmailLogOnly($to, $subject, $message) {
        $logFile = __DIR__ . '/../logs/emails.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
        }
        
        $logEntry = date('Y-m-d H:i:s') . "\n";
        $logEntry .= "To: $to\n";
        $logEntry .= "Subject: $subject\n";
        $logEntry .= "Message: " . strip_tags($message) . "\n";
        $logEntry .= str_repeat("-", 50) . "\n\n";
        
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        
        $this->logNotification(null, 'email', $subject, $message, 'logged');
        return true;
    }
    
    // Send SMS (log only for now)
    public function sendSMS($phone, $message) {
        $logFile = __DIR__ . '/../logs/sms.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
        }
        
        $logEntry = date('Y-m-d H:i:s') . " - To: $phone - Message: $message\n";
        file_put_contents($logFile, $logEntry, FILE_APPEND);
        
        $this->logNotification(null, 'sms', 'SMS', $message, 'logged');
        return true;
    }
    
    // Registration email
    public function sendRegistrationEmail($email, $name, $username, $password) {
        $content = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
            <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;'>
                <h1 style='margin: 0; font-size: 28px;'>Welcome to EduSmart Pro!</h1>
            </div>
            <div style='background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;'>
                <p>Dear <strong>$name</strong>,</p>
                <p>Your account has been created successfully.</p>
                <div style='background: white; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 4px solid #667eea;'>
                    <p><strong>Username:</strong> $username</p>
                    <p><strong>Password:</strong> $password</p>
                </div>
                <p style='text-align: center;'>
                    <a href='" . SITE_URL . "auth/login.php' style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login to Dashboard</a>
                </p>
            </div>
        </div>
        ";
        
        // Try to send real email, fallback to log
        return $this->sendEmail($email, "Welcome to EduSmart Pro!", $content);
    }
    
    // Certificate notification
    public function sendCertificateNotification($email, $phone, $courseName, $certificateNo) {
        $content = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
            <div style='background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;'>
                <h1 style='margin: 0; font-size: 28px;'>🎉 Congratulations!</h1>
            </div>
            <div style='background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;'>
                <p>Dear Student,</p>
                <p>You have successfully completed <strong>$courseName</strong>.</p>
                <p>Your certificate is now available.</p>
                <div style='background: white; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 4px solid #43e97b;'>
                    <p><strong>Certificate Number:</strong> $certificateNo</p>
                </div>
                <p style='text-align: center;'>
                    <a href='" . SITE_URL . "student/certificate.php' style='background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;'>Download Certificate</a>
                </p>
            </div>
        </div>
        ";
        
        // Send email
        $this->sendEmail($email, "Certificate of Completion - $courseName", $content);
        
        // SMS log
        $this->sendSMS($phone, "Congratulations! You've earned a certificate for $courseName");
        
        return true;
    }
    
    // Build email template
    private function buildEmailTemplate($title, $content) {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 10px; overflow: hidden; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }
                .header h1 { margin: 0; font-size: 28px; }
                .content { padding: 30px; background: #f9f9f9; }
                .button { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
                .footer { background: #333; color: white; padding: 20px; text-align: center; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>' . SITE_NAME . '</h1>
                </div>
                <div class="content">
                    <h2>' . $title . '</h2>
                    ' . $content . '
                </div>
                <div class="footer">
                    <p>&copy; ' . date('Y') . ' ' . SITE_NAME . '</p>
                </div>
            </div>
        </body>
        </html>
        ';
    }
    
    // Log notification
    private function logNotification($user_id, $type, $subject, $message, $status) {
        // Create notifications table if it doesn't exist
        $this->createNotificationsTable();
        
        $query = "INSERT INTO notifications (user_id, type, subject, message, status, sent_at) VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("issss", $user_id, $type, $subject, $message, $status);
        $stmt->execute();
    }
    
    // Create notifications table if not exists
    private function createNotificationsTable() {
        $sql = "CREATE TABLE IF NOT EXISTS notifications (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NULL,
            type ENUM('email','sms') DEFAULT 'email',
            subject VARCHAR(255),
            message TEXT,
            status ENUM('pending','sent','failed','logged') DEFAULT 'pending',
            sent_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $this->conn->query($sql);
    }
}
?>